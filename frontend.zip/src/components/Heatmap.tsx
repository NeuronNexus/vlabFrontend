import { useEffect, useRef } from 'react';
import { GRID_WIDTH, GRID_HEIGHT } from '@/types/simulation';

interface HeatmapProps {
  grid: number[][];
  maxValue: number;
  title: string;
  type: 'pressure' | 'wear';
  width?: number;
  height?: number;
}

function getColor(value: number, max: number, type: 'pressure' | 'wear'): string {
  if (value === 0) return 'rgba(15, 23, 42, 0.3)';
  
  const ratio = Math.min(1, value / max);
  
  if (type === 'pressure') {
    // Blue -> Cyan -> Yellow -> Orange -> Red
    if (ratio < 0.25) return `hsl(${210 - ratio * 120}, 100%, ${50 + ratio * 10}%)`;
    if (ratio < 0.5) return `hsl(${180 - (ratio - 0.25) * 240}, 100%, ${60 - (ratio - 0.25) * 10}%)`;
    if (ratio < 0.75) return `hsl(${120 - (ratio - 0.5) * 300}, 100%, 50%)`;
    return `hsl(${45 - (ratio - 0.75) * 180}, 100%, ${50 - (ratio - 0.75) * 10}%)`;
  } else {
    // Green -> Yellow -> Orange -> Red (wear)
    if (ratio < 0.33) return `hsl(${142 - ratio * 186}, 76%, 45%)`;
    if (ratio < 0.66) return `hsl(${80 - (ratio - 0.33) * 106}, 60%, 45%)`;
    return `hsl(${45 - (ratio - 0.66) * 132}, 100%, ${50 - (ratio - 0.66) * 30}%)`;
  }
}

export function Heatmap({ grid, maxValue, title, type, width = 240, height = 400 }: HeatmapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.fillStyle = 'hsl(222, 47%, 6%)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const padding = 10;
    const legendWidth = 40;
    const cellWidth = (canvas.width - padding * 2 - legendWidth) / GRID_WIDTH;
    const cellHeight = (canvas.height - padding * 2) / GRID_HEIGHT;
    const offsetX = padding + legendWidth;
    const offsetY = padding;

    // Draw cells
    for (let y = 0; y < GRID_HEIGHT; y++) {
      for (let x = 0; x < GRID_WIDTH; x++) {
        const value = grid[y]?.[x] || 0;
        ctx.fillStyle = getColor(value, maxValue, type);
        ctx.fillRect(
          offsetX + x * cellWidth,
          offsetY + y * cellHeight,
          cellWidth - 0.5,
          cellHeight - 0.5
        );
      }
    }

    // Draw legend
    const legendHeight = (canvas.height - padding * 2) * 0.8;
    const legendY = offsetY + (canvas.height - padding * 2 - legendHeight) / 2;
    
    const gradient = ctx.createLinearGradient(0, legendY + legendHeight, 0, legendY);
    if (type === 'pressure') {
      gradient.addColorStop(0, 'hsl(210, 100%, 50%)');
      gradient.addColorStop(0.25, 'hsl(180, 100%, 55%)');
      gradient.addColorStop(0.5, 'hsl(120, 100%, 50%)');
      gradient.addColorStop(0.75, 'hsl(45, 100%, 50%)');
      gradient.addColorStop(1, 'hsl(0, 100%, 45%)');
    } else {
      gradient.addColorStop(0, 'hsl(142, 76%, 45%)');
      gradient.addColorStop(0.33, 'hsl(80, 60%, 45%)');
      gradient.addColorStop(0.66, 'hsl(45, 100%, 50%)');
      gradient.addColorStop(1, 'hsl(0, 100%, 40%)');
    }

    ctx.fillStyle = gradient;
    ctx.fillRect(padding / 2, legendY, 12, legendHeight);

    // Labels
    ctx.fillStyle = 'hsl(215, 20%, 55%)';
    ctx.font = '9px JetBrains Mono';
    ctx.textAlign = 'left';
    ctx.fillText(`${Math.round(maxValue)}`, padding / 2 + 15, legendY + 8);
    ctx.fillText(type === 'pressure' ? 'kPa' : '%', padding / 2 + 15, legendY + 18);
    ctx.fillText('0', padding / 2 + 15, legendY + legendHeight);
  }, [grid, maxValue, type]);

  return (
    <div className="relative bg-background/50 rounded-lg overflow-hidden border border-border">
      <div className="absolute top-2 left-2 right-2 text-center">
        <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
          {title}
        </span>
      </div>
      <canvas ref={canvasRef} width={width} height={height} className="block" />
    </div>
  );
}
